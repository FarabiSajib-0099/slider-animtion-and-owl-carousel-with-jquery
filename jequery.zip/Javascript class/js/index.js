(function ($) {
    "use strict";

    /*--------------------------------------
        Nivo Slider Active
    ----------------------------------------*/
    $('.slider-active').nivoSlider({
        controlNav: true,
        directionNav: true,
        randomStart: true,
        controlNavThumbs: false,
        animSpeed: 300,
        pauseTime: 3000,
        pauseOnHover: false,
        manualAdvance: false,
        prevText: '<i class="fa fa-angle-left"></i>',
        nextText: '<i class="fa fa-angle-right"></i>',
        slices: 15,
        boxCols: 8,
        boxRows: 4,
    });

})(jQuery);









$('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        }
    }
});